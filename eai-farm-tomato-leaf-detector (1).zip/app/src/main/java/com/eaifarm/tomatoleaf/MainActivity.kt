package com.eaifarm.tomatoleaf

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.eaifarm.tomatoleaf.databinding.ActivityMainBinding
import com.gun0912.tedimagepicker.builder.TedImagePicker
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.image.TensorImage
import org.tensorflow.lite.support.tensorbuffer.TensorBuffer
import java.nio.ByteBuffer

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var tflite: Interpreter

    private val labels = arrayOf("Healthy", "Early Blight", "Late Blight", "Septoria Leaf Spot")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val modelBuffer = assets.open("tomato_leaf_disease_model.tflite").readBytes()
        tflite = Interpreter(modelBuffer)

        binding.btnPick.setOnClickListener {
            TedImagePicker.with(this)
                .start { uri ->
                    val inputStream = contentResolver.openInputStream(uri)
                    val bitmap = BitmapFactory.decodeStream(inputStream)
                    binding.imageView.setImageBitmap(bitmap)
                    val result = classify(bitmap)
                    binding.txtResult.text = "Prediction: $result"
                }
        }
    }

    private fun classify(bitmap: Bitmap): String {
        val resized = Bitmap.createScaledBitmap(bitmap, 224, 224, false)
        val tensorImage = TensorImage.fromBitmap(resized)
        val inputBuffer: ByteBuffer = tensorImage.buffer
        val outputBuffer = TensorBuffer.createFixedSize(intArrayOf(1, labels.size), TensorBuffer.FLOAT32)
        tflite.run(inputBuffer, outputBuffer.buffer.rewind())
        val scores = outputBuffer.floatArray
        val maxIdx = scores.indices.maxByOrNull { scores[it] } ?: -1
        return labels[maxIdx]
    }

    override fun onDestroy() {
        super.onDestroy()
        tflite.close()
    }
}
